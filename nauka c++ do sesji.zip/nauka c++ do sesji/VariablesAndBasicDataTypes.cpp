#include <iostream>

int main() {
    
    // int x = 5; /* IT COULD BE 
    
    // int x; //declaration

    // x = 5; //assignment */
    // int y = 6;
    // int sum = x + y;
    

    // std::cout << x << '\n' << y << '\n';
    // std::cout << sum << '\n';

    int age = 21;
    int yeat = 2023; //whole numbers
    int days = 7.5; //for output reasons its decimal has decimal portions
    double price = 2.53; //number including decimal
    char grade = 'B'; //singe character
    // char ToMuchChars = 'CD';
    bool student = true; // boolean

    std::string andrzej = "andrzej"; 

    std::cout << days << '\n'; 
    std::cout << price << "zl" << '\n';
    std::cout << grade << '\n';
    // std::cout << ToMuchChars;
    std::cout << andrzej << '\n';

    return 0;
}