#include <iostream>

int main() {
    std::cout << "plik" << '\n';
    std::cout << "pierwszy" << '\n';

    return 0;
}